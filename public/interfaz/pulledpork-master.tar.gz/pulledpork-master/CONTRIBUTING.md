Nothing special here, if you write something that works and improves pulledpork, it will be brought in.
The preferred method is a pull request against the master branch, but patches can be submitted and attached to issues. 
